#ifndef Step_Motor_H
#define Step_Motor_h
void Motor_Movex(uint16_t nx,uint16_t delayx);
void Motor_Setdirx(uint16_t dirx);
#endif
