#include "stm32f4xx_hal.h"
uint16_t nx=0;
uint16_t dirx=0;
uint16_t delayx=0;
uint16_t ny=0;
uint16_t diry=0;
uint16_t delayy=0;
void Motor_Movex(uint16_t nx,uint16_t delayx)
{
//	if(delayx<16)delayx=16;
	if(delayx>500)delayx=500;
	for(uint16_t i=0;i<nx;i++)
	{
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1, GPIO_PIN_SET);
//		osDelay(1);
		delay_us(delayx);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_1, GPIO_PIN_RESET);
		delay_us(delayx);
//		osDelay(1);
	}
}
void Motor_Setdirx(uint16_t dirx)
{
	if(dirx==1)//forward
		{
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0, GPIO_PIN_SET);
		}
		else
		{
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0, GPIO_PIN_RESET);
		}
}
void Motor_Movey(uint16_t ny,uint16_t delayy)
{
//	if(delayy<16)delayy=16;
	if(delayy>500)delayy=500;
	for(uint16_t i=0;i<ny;i++)
	{
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3, GPIO_PIN_SET);
//		osDelay(1);
		delay_us(delayy);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3, GPIO_PIN_RESET);
		delay_us(delayy);
//		osDelay(1);
	}
}
void Motor_Setdiry(uint16_t diry)
{
	if(diry==1)//forward
		{
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2, GPIO_PIN_SET);
		}
		else
		{
			HAL_GPIO_WritePin(GPIOC,GPIO_PIN_2, GPIO_PIN_RESET);
		}
}
//os_delay
void delay_us(uint32_t nus)
{
       uint32_t ticks;
       uint32_t told,tnow,reload,tcnt=0;
       if((0x0001&(SysTick->CTRL)) ==0)    //定时器未工作
              vPortSetupTimerInterrupt();  //初始化定时器

       reload = SysTick->LOAD;                     //获取重装载寄存器值
       ticks = nus * (SystemCoreClock / 1000000);  //计数时间值

       //vTaskSuspendAll();//阻止OS调度，防止打断us延时
       told=SysTick->VAL;  //获取当前数值寄存器值（开始时数值）
       while(1)
       {
              tnow=SysTick->VAL; //获取当前数值寄存器值
              if(tnow!=told)  //当前值不等于开始值说明已在计数
              {
                     if(tnow<told)  //当前值小于开始数值，说明未计到0
                          tcnt+=told-tnow; //计数值=开始值-当前值

                     else     //当前值大于开始数值，说明已计到0并重新计数
                            tcnt+=reload-tnow+told;   //计数值=重装载值-当前值+开始值  （
                                                      //已从开始值计到0）

                     told=tnow;   //更新开始值
                     if(tcnt>=ticks)break;  //时间超过/等于要延迟的时间,则退出.
              }
       }
//       xTaskResumeAll();	//恢复OS调度
}
//SystemCoreClock为系统时钟(system_stmf4xx.c中)，通常选择该时钟作为
//systick定时器时钟，根据具体情况更改

////HAL
//void delay_us(uint32_t udelay)
//{
//  uint32_t startval,tickn,delays,wait;
//
//  startval = SysTick->VAL;
//  tickn = HAL_GetTick();
//  //sysc = 72000;  //SystemCoreClock / (1000U / uwTickFreq);
//  delays =udelay * 72; //sysc / 1000 * udelay;
//  if(delays > startval)
//    {
//      while(HAL_GetTick() == tickn)
//        {
//
//        }
//      wait = 72000 + startval - delays;
//      while(wait < SysTick->VAL)
//        {
//
//        }
//    }
//  else
//    {
//      wait = startval - delays;
//      while(wait < SysTick->VAL && HAL_GetTick() == tickn)
//        {
//
//        }
//    }
//}
